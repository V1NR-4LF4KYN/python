# Toadie
# Code Angel

# Classes: Toad

import pygame

import toadie
import world

# Define constants
TOAD_START_X = 6
TOAD_START_Y = world.PAVEMENT_LANE_1

TOAD_DEATH_TIME = 2